<?php

class test1 {
  function test() {
    echo "test\n";
  }
}

